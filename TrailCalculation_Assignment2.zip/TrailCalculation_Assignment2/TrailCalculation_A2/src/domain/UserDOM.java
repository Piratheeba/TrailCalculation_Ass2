package domain;

public class UserDOM {
	private String full_name;
	private String NICNO;
	
	
	
	public UserDOM(String full_name, String nICNO) {
		this.full_name = full_name;
		NICNO = nICNO;
	}
	
	public UserDOM() {
		
	}
	
	public String getFull_name() {
		return full_name;
	}
	public void setFull_name(String full_name) {
		this.full_name = full_name;
	}
	
	public String getNICNO() {
		return NICNO;
	}
	public void setNICNO(String nICNO) {
		NICNO = nICNO;
	}
	
}
