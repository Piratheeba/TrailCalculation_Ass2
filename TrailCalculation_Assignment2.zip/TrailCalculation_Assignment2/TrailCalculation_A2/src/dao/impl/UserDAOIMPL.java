package dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import connection.DBConnectionSQL;
import dao.UserDAO;
import domain.UserDOM;

public class UserDAOIMPL implements UserDAO {
	
	private final String INSERT_USER_SQL = "INSERT INTO `user` (`NICNO`, `Full_Name`) VALUES (?, ?);";	
	private final String GET_USER_SQL = "SELECT * FROM `user` WHERE `NICNO`=?;" ;

	@Override
	public boolean insert(UserDOM user) {
		boolean value=true;
		DBConnectionSQL newj=new DBConnectionSQL();
		Connection conn= newj.get_connection();		
		PreparedStatement ps;
		try {
			ps = conn.prepareStatement(INSERT_USER_SQL);
			ps.setString(2, user.getFull_name());
			ps.setString(1, user.getNICNO());			
			int count=ps.executeUpdate();
			if(count<0) {
				value=false;
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
			} 
	
		return value;
	}

	@Override
	public ResultSet select(UserDOM user) {
		ResultSet result=null;	
		DBConnectionSQL newconn=new DBConnectionSQL();
		Connection conn= newconn.get_connection();
		PreparedStatement statement;
		try {
			statement = conn.prepareStatement(this.GET_USER_SQL);
			statement.setString(1, user.getNICNO());
			result = statement.executeQuery();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return result;		
	}
}
