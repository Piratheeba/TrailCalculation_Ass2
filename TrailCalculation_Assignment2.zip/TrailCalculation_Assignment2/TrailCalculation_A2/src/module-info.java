/**
 * 
 */
/**
 * @author pc
 *
 */
module TrailCalculation3rdAttempt {
	requires java.sql;
}