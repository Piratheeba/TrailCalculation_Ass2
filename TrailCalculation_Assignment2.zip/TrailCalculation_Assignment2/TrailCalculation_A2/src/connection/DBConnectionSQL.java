package connection;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnectionSQL {

	public  Connection get_connection() {
		Connection c = null;
		try {			
			c=DriverManager.getConnection("jdbc:mysql://localhost:3306/tcalculation","root","");
		} 
		catch (Exception e) {
			System.out.print(e);
		}
		return c;
	}

}
